#!/bin/bash

while true; do
    echo "1. Afficher les tâches"
    echo "2. Créer une tâche"
    echo "3. Supprimer une tâche"
    echo "4. Rechercher une tâche par titre"
    echo "5. Lister les tâches d'un jour donné (complétées et non complétées)"
    echo "6. Mettre à jour une tâche"
    echo "7. Exit"
    read -p "Choisir du menu : " choix

    if [ $choix -eq 1 ]; then
        afficher() {
            cat task
        }
        afficher
    elif [ $choix -eq 2 ]; then
        creat() {
            id=$(wc -l < 'task')
            res=$((id + 1))

            read -p "Entrer le titre : " titre
            read -p "Entrer la description : " description
            read -p "Entrer la localisation : " location
            read -p "Entrer la date sous forme jj-mm-aaaa hh:mm : " date
            read -p "La tâche est-elle complétée ? (oui/non) : " complete

            if [ -z "$date" ] || [ -z "$titre" ]; then
                echo "Veuillez entrer le titre et la date dans le format demandé."
            else
                echo "ID : $res | Titre : $titre | Description : $description | Localisation : $location | Date : $date | Complété : $complete" >> task
                echo "Tâche créée avec succès."
            fi
        }
        creat
    elif [ $choix -eq 3 ]; then
        read -p "Entrer le titre de la tâche à supprimer : " veuxsupprimer
        motif=$(grep "$veuxsupprimer" task)
        if [ -n "$motif" ]; then
            sed -i "/$motif/d" task
            echo "Tâche supprimée avec succès."
        else
            echo "Tâche non trouvée."
        fi
        cat task
    elif [ $choix -eq 4 ]; then
        read -p "Entrer le titre de la tâche pour afficher les détails : " tache
        info=$(grep "$tache" task)
        if [ -n "$info" ]; then
            echo "$info"
        else
            echo "Tâche non trouvée."
        fi
    elif [ $choix -eq 5 ]; then
        read -p "Entrer la date (jj-mm-aaaa) : " date_jour
        echo "Tâches complétées le $date_jour :"
        grep "Date : $date_jour" task | grep "Complété : oui"
        echo ""
        echo "Tâches non complétées le $date_jour :"
        grep "Date : $date_jour" task | grep "Complété : non"
    elif [ $choix -eq 6 ]; then
        read -p "Entrer le titre de la tâche à mettre à jour : " titre
        motif=$(grep "$titre" task)
        if [ -n "$motif" ]; then
            echo "Tâche trouvée : $motif"
            read -p "Entrer le nouveau titre (laisser vide pour ne pas changer) : " nouveau_titre
            read -p "Entrer la nouvelle description (laisser vide pour ne pas changer) : " nouvelle_description
            read -p "Entrer la nouvelle localisation (laisser vide pour ne pas changer) : " nouvelle_location
            read -p "Entrer la nouvelle date (jj-mm-aaaa hh:mm, laisser vide pour ne pas changer) : " nouvelle_date
            read -p "La tâche est-elle complétée ? (oui/non, laisser vide pour ne pas changer) : " nouvelle_complete

            if [ -n "$nouveau_titre" ]; then
                motif=$(echo "$motif" | sed "s|Titre : [^|]*|Titre : $nouveau_titre|")
            fi
            if [ -n "$nouvelle_description" ]; then
                motif=$(echo "$motif" | sed "s|Description : [^|]*|Description : $nouvelle_description|")
            fi
            if [ -n "$nouvelle_location" ]; then
                motif=$(echo "$motif" | sed "s|Localisation : [^|]*|Localisation : $nouvelle_location|")
            fi
            if [ -n "$nouvelle_date" ]; then
                motif=$(echo "$motif" | sed "s|Date : [^|]*|Date : $nouvelle_date|")
            fi
            if [ -n "$nouvelle_complete" ]; then
                motif=$(echo "$motif" | sed "s|Complété : [^|]*|Complété : $nouvelle_complete|")
            fi

            sed -i "/$titre/c\\$motif" task
            echo "Tâche mise à jour avec succès."
        else
            echo "Tâche non trouvée."
        fi
    elif [ $choix -eq 7 ]; then
        echo "Adios!"
        exit 0
    else
        echo "Veuillez entrer un nombre entre 1 et 7."
    fi

    echo ""
done
